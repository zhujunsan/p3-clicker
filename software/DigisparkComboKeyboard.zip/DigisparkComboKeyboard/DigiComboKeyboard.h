/*
 * Based on Obdev's AVRUSB code and under the same license.
 *
 * TODO: Make a proper file header. :-)
 * Modified for Digispark by Digistump
 */
#ifndef __DigiComboKeyboard_h__
#define __DigiComboKeyboard_h__

#include <Arduino.h>
#include <avr/pgmspace.h>
#include <avr/interrupt.h>
#include <util/delay.h>
#include <string.h>

#include "usbdrv.h"
#include "keylayouts.h"

typedef uint8_t byte;

#define TEST_STRING "abcdefghijklmnopqrstuvwxyz ABCDEFGHIJKLMNOPQRSTUVWXYZ 1234567890 !\"#$%&'()*+,-./:;<=>?@[\\]^_`{|}~"

#define BUFFER_SIZE 2 // Minimum of 2: 1 for modifiers + 1 for keystroke

#define REPID_MOUSE         1
#define REPID_KEYBOARD      2
#define REPID_MMKEY         3
#define REPID_SYSCTRLKEY    4
#define REPSIZE_MOUSE       4
#define REPSIZE_KEYBOARD    8
#define REPSIZE_MMKEY       3
#define REPSIZE_SYSCTRLKEY  2

static uchar idleRate = 500 / 4;           // in 125 ms units
static uchar protocolVersion = 0;

/* We use a simplifed keyboard report descriptor which does not support the
 * boot protocol. We don't allow setting status LEDs and but we do allow
 * simultaneous key presses.
 * The report descriptor has been created with usb.org's "HID Descriptor Tool"
 * which can be downloaded from http://www.usb.org/developers/hidpage/.
 * Redundant entries (such as LOGICAL_MINIMUM and USAGE_PAGE) have been omitted
 * for the second INPUT item.
 */
// USB_CFG_HID_REPORT_DESCRIPTOR_LENGTH is defined in usbconfig (should be 173)
const PROGMEM uchar usbHidReportDescriptor[USB_CFG_HID_REPORT_DESCRIPTOR_LENGTH] = {
        0x05, 0x01,           // USAGE_PAGE (Generic Desktop)
        0x09, 0x02,           // USAGE (Mouse)
        0xa1, 0x01,           // COLLECTION (Application)
        0x09, 0x01,           //   USAGE (Pointer)
        0xA1, 0x00,           //   COLLECTION (Physical)
        0x85, REPID_MOUSE,    //     REPORT_ID
        0x05, 0x09,           //     USAGE_PAGE (Button)
        0x19, 0x01,           //     USAGE_MINIMUM
        0x29, 0x03,           //     USAGE_MAXIMUM
        0x15, 0x00,           //     LOGICAL_MINIMUM (0)
        0x25, 0x01,           //     LOGICAL_MAXIMUM (1)
        0x95, 0x03,           //     REPORT_COUNT (3)
        0x75, 0x01,           //     REPORT_SIZE (1)
        0x81, 0x02,           //     INPUT (Data,Var,Abs)
        0x95, 0x01,           //     REPORT_COUNT (1)
        0x75, 0x05,           //     REPORT_SIZE (5)
        0x81, 0x03,           //     INPUT (Const,Var,Abs)
        0x05, 0x01,           //     USAGE_PAGE (Generic Desktop)
        0x09, 0x30,           //     USAGE (X)
        0x09, 0x31,           //     USAGE (Y)
        0x15, 0x81,           //     LOGICAL_MINIMUM (-127)
        0x25, 0x7F,           //     LOGICAL_MAXIMUM (127)
        0x75, 0x08,           //     REPORT_SIZE (8)
        0x95, 0x02,           //     REPORT_COUNT (2)
        0x81, 0x06,           //     INPUT (Data,Var,Rel)
        0xC0,                 //   END_COLLECTION
        0xC0,                 // END COLLECTION

        0x05, 0x01,           // USAGE_PAGE (Generic Desktop)
        0x09, 0x06,           // USAGE (Keyboard)
        0xA1, 0x01,           // COLLECTION (Application)
        0x85, REPID_KEYBOARD, // REPORT_ID
        0x75, 0x01,           //   REPORT_SIZE (1)
        0x95, 0x08,           //   REPORT_COUNT (8)
        0x05, 0x07,           //   USAGE_PAGE (Keyboard)(Key Codes)
        0x19, 0xE0,           //   USAGE_MINIMUM (Keyboard LeftControl)(224)
        0x29, 0xE7,           //   USAGE_MAXIMUM (Keyboard Right GUI)(231)
        0x15, 0x00,           //   LOGICAL_MINIMUM (0)
        0x25, 0x01,           //   LOGICAL_MAXIMUM (1)
        0x81, 0x02,           //   INPUT (Data,Var,Abs) ; Modifier byte
        0x95, 0x01,           //   REPORT_COUNT (1)
        0x75, 0x08,           //   REPORT_SIZE (8)
        0x81, 0x03,           //   INPUT (Cnst,Var,Abs) ; Reserved byte
        0x95, 0x05,           //   REPORT_COUNT (5)
        0x75, 0x01,           //   REPORT_SIZE (1)
        0x05, 0x08,           //   USAGE_PAGE (LEDs)
        0x19, 0x01,           //   USAGE_MINIMUM (Num Lock)
        0x29, 0x05,           //   USAGE_MAXIMUM (Kana)
        0x91, 0x02,           //   OUTPUT (Data,Var,Abs) ; LED report
        0x95, 0x01,           //   REPORT_COUNT (1)
        0x75, 0x03,           //   REPORT_SIZE (3)
        0x91, 0x03,           //   OUTPUT (Cnst,Var,Abs) ; LED report padding
        0x95, 0x05,           //   REPORT_COUNT (5)
        0x75, 0x08,           //   REPORT_SIZE (8)
        0x15, 0x00,           //   LOGICAL_MINIMUM (0)
        0x26, 0xA4, 0x00,     //   LOGICAL_MAXIMUM (164)
        0x05, 0x07,           //   USAGE_PAGE (Keyboard)(Key Codes)
        0x19, 0x00,           //   USAGE_MINIMUM (Reserved (no event indicated))(0)
        0x2A, 0xA4, 0x00,     //   USAGE_MAXIMUM (Keyboard Application)(164)
        0x81, 0x00,           //   INPUT (Data,Ary,Abs)
        0xC0,                 // END_COLLECTION

        // this second multimedia key report is what handles the multimedia keys
        0x05, 0x0C,           // USAGE_PAGE (Consumer Devices)
        0x09, 0x01,           // USAGE (Consumer Control)
        0xA1, 0x01,           // COLLECTION (Application)
        0x85, REPID_MMKEY,    //   REPORT_ID
        0x19, 0x00,           //   USAGE_MINIMUM (Unassigned)
        0x2A, 0x3C, 0x02,     //   USAGE_MAXIMUM
        0x15, 0x00,           //   LOGICAL_MINIMUM (0)
        0x26, 0x3C, 0x02,     //   LOGICAL_MAXIMUM
        0x95, 0x01,           //   REPORT_COUNT (1)
        0x75, 0x10,           //   REPORT_SIZE (16)
        0x81, 0x00,           //   INPUT (Data,Ary,Abs)
        0xC0,                 // END_COLLECTION

        // system controls, like power, needs a 3rd different report and report descriptor
        0x05, 0x01,             // USAGE_PAGE (Generic Desktop)
        0x09, 0x80,             // USAGE (System Control)
        0xA1, 0x01,             // COLLECTION (Application)
        0x85, REPID_SYSCTRLKEY, //   REPORT_ID
        0x95, 0x01,             //   REPORT_COUNT (1)
        0x75, 0x02,             //   REPORT_SIZE (2)
        0x15, 0x01,             //   LOGICAL_MINIMUM (1)
        0x25, 0x03,             //   LOGICAL_MAXIMUM (3)
        0x09, 0x81,             //   USAGE (System Power)
        0x09, 0x82,             //   USAGE (System Sleep)
        0x09, 0x83,             //   USAGE (System Wakeup)
        0x81, 0x60,             //   INPUT
        0x75, 0x06,             //   REPORT_SIZE (6)
        0x81, 0x03,             //   INPUT (Cnst,Var,Abs)
        0xC0,                   // END_COLLECTION
};

#define MOD_CONTROL_LEFT    MODIFIERKEY_LEFT_CTRL
#define MOD_SHIFT_LEFT      MODIFIERKEY_LEFT_SHIFT
#define MOD_ALT_LEFT        MODIFIERKEY_LEFT_ALT
#define MOD_GUI_LEFT        MODIFIERKEY_LEFT_GUI
#define MOD_CONTROL_RIGHT   MODIFIERKEY_RIGHT_CTRL
#define MOD_SHIFT_RIGHT     MODIFIERKEY_RIGHT_SHIFT
#define MOD_ALT_RIGHT       MODIFIERKEY_RIGHT_ALT
#define MOD_GUI_RIGHT       MODIFIERKEY_RIGHT_GUI

class DigiComboKeyboardDevice: public Print {
public:
    DigiComboKeyboardDevice() {
        noInterrupts();

        usbDeviceDisconnect();
        _delay_ms(250);
        usbDeviceConnect();

        usbInit();

        interrupts();

        // TODO: Remove the next two lines once we fix
        //       missing first keystroke bug properly.
        memset(reportBuffer, 0, sizeof(reportBuffer));
//        usbSetInterrupt(reportBuffer, sizeof(reportBuffer));

        sei();
    }

    void update() {
        usbPoll();
    }

    // delay while updating until we are finished delaying
    void delay(long milli) {
        unsigned long last = millis();
        while (milli > 0) {
            unsigned long now = millis();
            milli -= now - last;
            last = now;
            update();
        }
    }

    void enableLEDFeedback() {
        sUseFeedbackLed = true;
        pinMode(LED_BUILTIN, OUTPUT);
    }

    void disableLEDFeedback() {
        sUseFeedbackLed = false;
    }

    void usbRemoteWakeup(void) {
        cli();

        int8_t ddr_orig = USBDDR;
        USBOUT |= (1 << USBMINUS);
        USBDDR = ddr_orig | USBMASK;
        USBOUT ^= USBMASK;

        _delay_ms(25);

        USBOUT ^= USBMASK;
        USBDDR = ddr_orig;
        USBOUT &= ~(1 << USBMINUS);

        sei();
    }

    void mouseMove(signed char x, signed char y, uint8_t buttonMask)
    {
        signed char * signed_ptr = (signed char *)report_buffer; // this converts signed to unsigned

        // format the report structure
        signed_ptr[2] = x;
        signed_ptr[3] = y;
        report_buffer[1] = buttonMask;
        report_buffer[0] = REPID_MOUSE;

        usbReportSend(REPSIZE_MOUSE);
    }

    void pressKey(uint8_t keycode1)
    {
        pressKey(0, keycode1, 0, 0, 0, 0);
    }

    void pressKey(uint8_t modifiers, uint8_t keycode1)
    {
        pressKey(modifiers, keycode1, 0, 0, 0, 0);
    }

    void pressKey(uint8_t modifiers, uint8_t keycode1, uint8_t keycode2)
    {
        pressKey(modifiers, keycode1, keycode2, 0, 0, 0);
    }

    void pressKey(uint8_t modifiers, uint8_t keycode1, uint8_t keycode2, uint8_t keycode3)
    {
        pressKey(modifiers, keycode1, keycode2, keycode3, 0, 0);
    }

    void pressKey(uint8_t modifiers, uint8_t keycode1, uint8_t keycode2, uint8_t keycode3, uint8_t keycode4)
    {
        pressKey(modifiers, keycode1, keycode2, keycode3, keycode4, 0);
    }

    void pressKey(uint8_t modifiers, uint8_t keycode1, uint8_t keycode2, uint8_t keycode3, uint8_t keycode4, uint8_t keycode5)
    {
        // construct the report, follow the standard format as described
        // this format is compatible with "boot protocol"
        report_buffer[1] = modifiers;
        report_buffer[2] = 0; // reserved
        report_buffer[3] = keycode1;
        report_buffer[4] = keycode2;
        report_buffer[5] = keycode3;
        report_buffer[6] = keycode4;
        report_buffer[7] = keycode5;
        report_buffer[0] = REPID_KEYBOARD;
        usbReportSend(REPSIZE_KEYBOARD);
    }

    void keyDownNormalKey(uint8_t key)
    {
        pressKey(key);
    }

    void keyUpNormalKey()
    {
        pressKey(0);
    }

    void clickNormalKey(uint8_t key)
    {
        keyDownNormalKey(key);
        // immediate release
        keyUpNormalKey();
    }

    void keyDownMultimediaKey(uint8_t key)
    {
        report_buffer[0] = REPID_MMKEY;
        report_buffer[1] = key;
        report_buffer[2] = 0;
        usbReportSend(REPSIZE_MMKEY);
    }

    void keyUpMultimediaKey()
    {
        report_buffer[0] = REPID_MMKEY;
        report_buffer[1] = 0;
        report_buffer[2] = 0;
        usbReportSend(REPSIZE_MMKEY);
    }

    void clickMultimediaKey(uint8_t key)
    {
        keyDownMultimediaKey(key);
        // immediate release
        keyUpMultimediaKey();
    }

    void keyDownSystemCtrlKey(uint8_t key)
    {
        report_buffer[0] = REPID_SYSCTRLKEY;
        report_buffer[1] = key;
        usbReportSend(REPSIZE_SYSCTRLKEY);
    }

    void keyUpSystemCtrlKey()
    {
        report_buffer[0] = REPID_SYSCTRLKEY;
        report_buffer[1] = 0;
        usbReportSend(REPSIZE_SYSCTRLKEY);
    }

    void clickSystemCtrlKey(uint8_t key)
    {
        keyDownSystemCtrlKey(key);
        // immediate release
        keyUpSystemCtrlKey();
    }

    void usbReportSend(uint8_t sz)
    {
        // perform usb background tasks until the report can be sent, then send it
        while (1)
        {
            usbPoll(); // this needs to be called at least once every 10 ms
            if (usbInterruptIsReady())
            {
                usbSetInterrupt((uint8_t*)report_buffer, sz); // send
                break;

                // see http://vusb.wikidot.com/driver-api
            }
        }
    }

    uint8_t keycode_to_modifier(uint8_t keycode) {
        uint8_t modifier = 0;

#ifdef SHIFT_MASK
        if (keycode & SHIFT_MASK)
            modifier |= MODIFIERKEY_SHIFT;
#endif
#ifdef ALTGR_MASK
        if (keycode & ALTGR_MASK)
            modifier |= MODIFIERKEY_RIGHT_ALT;
#endif
#ifdef RCTRL_MASK
        if (keycode & RCTRL_MASK) modifier |= MODIFIERKEY_RIGHT_CTRL;
#endif
        return modifier;
    }

    /*
     * Mask keycodes to ascii subset (+ a few F keys)
     */
    uint8_t keycode_to_key(uint8_t keycode) {
        uint8_t key = keycode & KEYCODE_MASK_SCANCODE;
        // the only valid ASCII code which has a scancode > 63
        if (key == KEY_NON_US_BS_MAPPING) {
            key = (uint8_t) KEY_NON_US_BS;
        }
        return key;
    }

    /*
     * Convert ASCII to USB code
     */
    size_t write(uint8_t chr) {
        uint8_t data = 0;
        if (chr == '\b') {
            data = (uint8_t) KEY_BACKSPACE; // 0x08
        } else if (chr == '\t') {
            data = (uint8_t) KEY_TAB;       // 0x09
        } else if (chr == '\n') {
            data = (uint8_t) KEY_ENTER;     // 0x0A
        } else if (chr == '\r') {
            data = (uint8_t) KEY_ENTER;     // 0x0D
        } else if (chr >= 0x20) {
            // read from mapping table
            data = pgm_read_byte_near(keycodes_ascii + (chr - 0x20));
        }
        if (data) {
            pressKey(keycode_to_key(data), keycode_to_modifier(data));
        }
        return 1;
    }

    bool sUseFeedbackLed = false;
    uchar reportBuffer[2];    // buffer for HID reports [ 1 modifier byte + (len-1) key strokes]
    uint8_t report_buffer[8];
    using Print::write;
};

DigiComboKeyboardDevice DigiComboKeyboard = DigiComboKeyboardDevice();

#ifdef __cplusplus
extern "C" {
#endif
// USB_PUBLIC uchar usbFunctionSetup
uchar usbFunctionSetup(uchar data[8]) {
    usbRequest_t *rq = (usbRequest_t*) ((void*) data);

    usbMsgPtr = DigiComboKeyboard.reportBuffer; //
    if ((rq->bmRequestType & USBRQ_TYPE_MASK) == USBRQ_TYPE_CLASS) {
        /* class request type */

        switch (rq->bRequest)
        {
            case USBRQ_HID_GET_REPORT:
                /* wValue: ReportType (highbyte), ReportID (lowbyte) */

                // determine the return data length based on which report ID was requested
                if (rq->wValue.bytes[0] == REPID_MOUSE)      return REPSIZE_MOUSE;
                if (rq->wValue.bytes[0] == REPID_KEYBOARD)   return REPSIZE_KEYBOARD;
                if (rq->wValue.bytes[0] == REPID_MMKEY)      return REPSIZE_MMKEY;
                if (rq->wValue.bytes[0] == REPID_SYSCTRLKEY) return REPSIZE_SYSCTRLKEY;
                return 8; // default
            case USBRQ_HID_GET_IDLE:
                usbMsgPtr = &idleRate; // send data starting from this byte
                return 1; // send 1 byte
            case USBRQ_HID_SET_IDLE:
                idleRate = rq->wValue.bytes[1]; // read in idle rate
                return 0; // send nothing
            case USBRQ_HID_GET_PROTOCOL:
                usbMsgPtr = &protocolVersion; // send data starting from this byte
                return 1; // send 1 byte
            case USBRQ_HID_SET_PROTOCOL:
                protocolVersion = rq->wValue.bytes[1];
                return 0; // send nothing
            default: // do not understand data, ignore
                return 0; // send nothing
        }
    } else {
        /* no vendor specific requests implemented */
    }

    return 0;
}
#ifdef __cplusplus
} // extern "C"
#endif

#endif // __DigiComboKeyboard_h__
